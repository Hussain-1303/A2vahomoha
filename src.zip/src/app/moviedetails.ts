export interface MovieDetails {
        Name: string,
        Genre: string,
        id: number,
        Year: string,
        photo: string,
        Rating: number,
        Review: string
}
